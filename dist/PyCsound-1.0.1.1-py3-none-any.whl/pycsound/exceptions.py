class ScoreError(Exception):
    pass

class CsoundError(Exception):
    pass

class SaveError(Exception):
    pass

class FileExtensionError(Exception):
    pass

class CsoundFileCompilationError(Exception):
    pass